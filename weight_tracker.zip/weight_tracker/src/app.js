if(process.env.NODE_ENV !== 'production'){
    require('dotenv').config()
  } //loads in all our environment variable and sets them inside process.env
  

const express = require('express')
const app = express()
const path = require('path')
const port = 3400
const mongdb = require("./usersDB") //connect with mongodb file
const cors = require('cors');
const session = require("express-session");
const bcrypt = require('bcrypt')
const passport = require("passport");
const flash = require('express-flash')
const initializePassport = require('./passport-config');
initializePassport(
    passport, 
    email => users.find( user => user.email === email),
    id => users.find( user => user.id === id)

)
const methodOverride = require('method-override')//enable DELETE for logout functionality

const users = []

//middleware
app.use(express.json());
const templatePath = path.join(__dirname, '../templates'); //hbs file
app.use(express.static(path.join(__dirname, '../public'))); //css and js
app.set('view engine', 'hbs')
app.set('views', templatePath)
const srcPath = path.join(__dirname, '../src'); 
app.use('/src', express.static(srcPath));
app.use(express.urlencoded({extended:false}))//get user input and access them inside req variable in the post method
// Enable CORS for all routes
app.use(cors({
    // origin: 'http://localhost:your-client-port', // Replace with your client's port
    // methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    // credentials: true,
}));

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false, //doesnt resave if nothing is changed
    saveUninitialized: false //doesnt save empty valuE
}))

app.use(methodOverride('_method'))
app.use(passport.initialize())
app.use(passport.session())
app.use(flash())

// API Key
const RAPIDAPI_KEY = 'a1c3c10932msh19f6bf4a20cd9efp1e05eejsna1d63f210ce1';

// Routes
app.get('/', checkAuthenticated ,(req, res) => {
    res.render('homepage.hbs', {email: req.user.email});
});

app.get('/homepage', (req, res) => {
    res.render('homepage.hbs');
});

app.get('/signup', checkNotAuthenticated, (req, res) => {
    res.render('signup.hbs');
});

app.get('/signin', checkNotAuthenticated ,(req, res) => {
    res.render('signin.hbs');
});


app.get('/calorieTracker', checkNotAuthenticated ,(req, res) => {
    res.render('signin.hbs');
});



app.get('/food/:foodName', async (req, res) => {
    const foodName = req.params.foodName;                                                                

    try {
        const dietagramResponse = await fetch(`https://dietagram.p.rapidapi.com/apiFood.php?name=${encodeURIComponent(foodName)}&lang=pl`, {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': RAPIDAPI_KEY,  
                'X-RapidAPI-Host': 'dietagram.p.rapidapi.com',
            },
        });

        if (!dietagramResponse.ok) {
            throw new Error(`Dietagram API request failed with status: ${dietagramResponse.status}`);
        }

        const dietagramData = await dietagramResponse.text();
        res.send(dietagramData);
    } catch (error) {
        console.error('Error fetching data from Dietagram API:', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//sign up

app.post('/signup', checkNotAuthenticated, async (req, res) => {
    // const data = {
    //     name: req.body.name,
    //     email: req.body.email,
    //     password: req.body.password
        

    // }

    // await mongdb.insertMany([data])

    // res.render("signin")

    //Above is mongoDb way of singup

    try{
        const hashedPassword = await bcrypt.hash(req.body.password, 10)
        users.push({
          id: Date.now().toString(),
          email: req.body.email,
          password: hashedPassword
        })
        res.redirect('/signin')
      } catch {
        res.redirect('/signup')
    
      }
      console.log(users)


})

//sign in

// app.post('/signin', async (req, res) =>{ //navigate back to home.hbs when name and password matches

//     // try{
//     //     const checking = await mongdb.findOne({email:req.body.email})
        
//     //     if(checking.password === req.body.password)
//     //     {
//     //         res.render('homepage')
//     //     }

//     //     else{
//     //         res.render('failure')

//     //     }
//     // }

//     // catch(e){
//     //     res.render('failure')
//     // }

//     //ABOVE IS MONGODB VERISON

// })

app.post('/signin', checkNotAuthenticated, passport.authenticate('local', {
    successRedirect: '/calorieTracker',
    failureRedirect: '/signin',
    failureFlash: true
  }))

//Authentication methods

function checkAuthenticated(req, res, next){
    if(req.isAuthenticated()){
        return next()
    }
    res.redirect('/signin'); // Redirect to sign-in page if not authenticated
}

function checkNotAuthenticated(req, res, next){
    if(req.isAuthenticated()){
      return res.redirect('/calorieTracker')
    }
    next()
  }

  app.delete('/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return next(err);
      }
      res.redirect('/signin');
    });
  });
  

  

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});