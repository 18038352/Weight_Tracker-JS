let addEntryBtn = document.getElementById('addEntry');

addEntryBtn.addEventListener('click', async () => {
    const foodInput = document.getElementById('food');
    const foodName = foodInput.value;

    try {
        const response = await fetch(`/food/${encodeURIComponent(foodName)}`);

        if (!response.ok) {
            throw new Error(`Server request failed with status: ${response.status}`);
        }

        const foodData = await response.json();

        console.log('Food Data:', foodData);

        const entryList = document.getElementById('entry-list');
        const entryItem = document.createElement('li');

        if (foodData.dishes && foodData.dishes.length > 0) {
            const dish = foodData.dishes[0]; // Take the first dish from the array

            entryItem.textContent = `${dish.name}: ${dish.caloric} calories, ${dish.fat}g fat, ${dish.carbon}g carbs, ${dish.protein}g protein`;
        } else {
            entryItem.textContent = 'Food not found in Dietagram database.';
        }

        entryList.appendChild(entryItem);
    } catch (error) {
        console.error('Error fetching data from server:', error.message);
    }
    
    foodInput.value = ""

});

