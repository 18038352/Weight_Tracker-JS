const { authenticate } = require('passport')
const bcrypt = require('bcrypt')
const LocalStrategy = require('passport-local').Strategy

// Initialize passport with a custom authentication strategy
function initialize(passport, getUserByEmail, getUserById){
    // Define the authentication logic for the local strategy
    const authenticateUser = async (email, password, done) =>{

        //retrieve user info based on the provided email
        const user = getUserByEmail(email)

        //check if the user exists
        if (user === null){

            //if no user found, return an error message
            return done(null, false, { message: 'No user with that name' })

        }

        try {
            // Compare the provided password with the hashed password in the database
            if(await bcrypt.compare(password, user.password)){
                // If passwords match, authentication is successful, return the user
                return done(null, user)
            }
    
            else{
                // If passwords don't match, return an error message
                return done(null, false, {message: 'Password is incorrect'})
            }
    
        } catch (e){
            // Handle any errors the occur during the comparison
            return done(e)
        }
    };

    //Use the local strategy with the defined authentication function
    passport.use(new LocalStrategy({ usernameField: 'email'}, authenticateUser))

    //Serialize user information to store in the session
    passport.serializeUser((user, done) => done(null, user.id))

    //Deserialize user information from the session
    passport.deserializeUser((id, done) =>{
        //Retrieve user info based on the user ID stored in the session
        return done(null, getUserById(id))
})


    
}


//Export the initialize function to be used in other files
module.exports = initialize

